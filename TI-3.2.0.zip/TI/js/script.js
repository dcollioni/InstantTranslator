﻿var imagens;
var menuOriginal;
var menuTraducao;
var textoOriginal;
var textoTraduzido;
var header;
var original;
var imagemOriginal;
var imagemTraducao;
var imagemTraduzir;
var imagemInverter;
var idiomaOriginal;
var idiomaTraducao;
var legendaTraducao;
var imagemMais;

var translatorUrl = 'http://api.microsofttranslator.com/V2/Ajax.svc/Translate',
    appId = '121986EA11F8EFFC1DE7F32521E3E83047CC7DCF',
    callback = 'SetTranslatedValue';

function Iniciar() {

    InicializarVariaveis();
    InicializarEventos();

    ObterSelecao();
}

function InicializarVariaveis() {

    imagens = [
        { id: 1, src: 'images/flags/Brazil.png', name: 'Português', language: 'pt' },
        { id: 2, src: 'images/flags/UK.png', name: 'Inglês', language: 'en' },
        { id: 3, src: 'images/flags/Spain.png', name: 'Espanhol', language: 'es' },
        { id: 4, src: 'images/flags/France.png', name: 'Francês', language: 'fr' },
        { id: 5, src: 'images/flags/Italy.png', name: 'Italiano', language: 'it' },
        { id: 6, src: 'images/flags/Germany.png', name: 'Alemão', language: 'de' },
        { id: 7, src: 'images/flags/Japan.png', name: 'Japonês', language: 'ja' }
    ];

    menuOriginal = $('#menuOriginal');
    menuTraducao = $('#menuTraducao');
    imagemOriginal = $('#imagemOriginal');
    imagemTraducao = $('#imagemTraducao');
    imagemTraduzir = $('#imagemTraduzir');
    imagemInverter = $('#imagemInverter');
    imagemMais = $('#imagemMais');
    textoOriginal = $('#textoOriginal');
    textoTraduzido = $('#textoTraduzido');
    legendaTraducao = $('#legendaTraducao');
    header = $('header');
    original = $('#original');
    idiomaOriginal = 'en';
    idiomaTraducao = 'pt';

    header.unselectable();
    original.unselectable();
    imagemTraducao.unselectable();
    legendaTraducao.unselectable();

    menuOriginal.hide();
    menuTraducao.hide();
}

var delay = (function () {
    var timer = 0;
    return function (callback, ms) {
        clearTimeout(timer);
        timer = setTimeout(callback, ms);
    };
})();

function InicializarEventos() {

    textoOriginal.keyup(function () {
        delay(function () {
            Traduzir();
        }, 300);
    });

    imagemOriginal.click(function () { ToggleMenuOriginal(); });
    imagemTraducao.click(function() { ToggleMenuTraducao(); });
    imagemTraduzir.click(function() { Traduzir(); });
    imagemInverter.click(function () { Inverter(); });
    imagemMais.click(function () { MaisTraducoes(); });

    menuOriginal.children().click(function () {

        var imagemSelecionada = imagens[this.alt - 1];

        imagemOriginal.attr('alt', imagemSelecionada.id);
        imagemOriginal.attr('src', imagemSelecionada.src);
        imagemOriginal.attr('title', imagemSelecionada.name);
        idiomaOriginal = imagemSelecionada.language;

        Traduzir();
        ToggleMenuOriginal();
    });

    menuTraducao.children().click(function() {

        var imagemSelecionada = imagens[this.alt - 1];

        imagemTraducao.attr('alt', imagemSelecionada.id);
        imagemTraducao.attr('src', imagemSelecionada.src);
        imagemTraducao.attr('title', imagemSelecionada.name);
        idiomaTraducao = imagemSelecionada.language;

        Traduzir();
        ToggleMenuTraducao();
    });
}

function ToggleMenuOriginal() {

    if (menuOriginal.is(':visible')) {

        menuOriginal.fadeOut(200);
        textoOriginal.focus();
    }
    else {

        menuOriginal.fadeIn(300);
    }
}

function ToggleMenuTraducao() {

    if (menuTraducao.is(':visible')) {

        menuTraducao.fadeOut(200);
        textoOriginal.focus();
    }
    else {

        menuTraducao.fadeIn(300);
    }
}

function ObterSelecao() {

    chrome.tabs.getSelected(null, function (tab) {

        chrome.tabs.sendRequest(tab.id, { method: "getSelection" }, function (response) {

            textoOriginal.val(response.data);
            Traduzir();
        });
    });
}

function SetTranslatedValue(tValue) {
    $("#textoTraduzido").html(tValue.replace('<html>', '').replace('</ html>', '').replace(/</gi, '&lt;').replace(/>/gi, '&gt;'));
}

function Traduzir() {

    $.get(translatorUrl, {
        "oncomplete": callback,
        "appId": appId,
        "from": idiomaOriginal,
        "to": idiomaTraducao,
        "text": textoOriginal.val()
    });

//    google.language.translate(textoOriginal.val(), idiomaOriginal, idiomaTraducao,

//	function(result) {

//	    $("#textoTraduzido").html(result.translation.replace('<html>', '').replace('</ html>', '').replace(/</gi, '&lt;').replace(/>/gi, '&gt;'));
//	});
}
	
function Inverter() {

    var imgOriginal = imagens[imagemOriginal[0].alt - 1];
    var imgTraducao = imagens[imagemTraducao[0].alt - 1];

    imagemOriginal.attr('alt', imgTraducao.id);
    imagemOriginal.attr('src', imgTraducao.src);
    imagemOriginal.attr('title', imgTraducao.name);
    idiomaOriginal = imgTraducao.language;

    imagemTraducao.attr('alt', imgOriginal.id);
    imagemTraducao.attr('src', imgOriginal.src);
    imagemTraducao.attr('title', imgOriginal.name);
    idiomaTraducao = imgOriginal.language;

    Traduzir();
    textoOriginal.focus();
}

function MaisTraducoes() {

    var text = textoOriginal.val().trim();

    if (text != '') {

        var imgOriginal = imagens[imagemOriginal[0].alt - 1];
        var imgTraducao = imagens[imagemTraducao[0].alt - 1];

        var encodedText = encodeURI(text);

        var params = imgOriginal.language + '|' + imgTraducao.language + '|' + encodedText;

        window.open('http://translate.google.com/#' + params);
    }
}